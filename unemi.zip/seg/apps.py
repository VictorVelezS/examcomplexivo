from django.apps import AppConfig


class SegConfig(AppConfig):
    name = 'seg'
